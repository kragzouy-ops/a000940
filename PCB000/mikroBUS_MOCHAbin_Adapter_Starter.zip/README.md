# MOCHAbin ⇄ mikroBUS Two-Part Adapter (Starter Pack)
Date: 2025-10-14

This pack contains a ready-to-use pin map, BOMs, and implementation notes for a two-board system:

- **Board A**: Base/Bridge for MOCHAbin — power, protection, level shifting, optional USB bridge; exposes a Pi-compatible 40-pin upward header (3.3V logic).
- **Board B**: Pi-HAT–shaped mikroBUS adapter — two mikroBUS sockets, ADC for AN pins, jumpers for CS/UART/PWM/INT/RST mapping, optional HAT EEPROM.

> Target logic level: **3.3 V** on all digital signals. 5V is power only to mikroBUS.

## Files
- `pin_map.csv` — 40-pin header to mikroBUS mapping (both sockets), including default GPIOs.
- `bom_board_a.csv` — Starter BOM for Board A (Base/Bridge).
- `bom_board_b.csv` — Starter BOM for Board B (HAT-mikroBUS).
- *(You can import the CSVs into your CAD/BOM tools. KiCad project skeleton can be made from these nets.)*

## Electrical Architecture (recap)
- Two selectable interface paths:
  1. **Native GPIO path**: MOCHAbin SPI/I2C/UART/PWM/INT/RST → level shifters (PCA9306 + SN74AXC8T245) → 3V3 header.
  2. **USB bridge path**: FT2232H or MCP2221A provides SPI/I2C/UART independent of SoC pinmux; ESD on D+/D−.
- Power: 12V→5V buck (≥3A), then 5V→3V3 (≥1A). Polyfuse on main 5V; per-socket 5V polyfuses; TVS on rails.
- I2C pull-ups: place on **Board A** (10k). Avoid duplicates on Board B.

## Default Signal Map (summary)
See `pin_map.csv`. Key defaults:
- CS0→Socket1 CS, CS1→Socket2 CS. 
- PWM0→Socket1 PWM, PWM1→Socket2 PWM.
- INT/RST pairs: (GPIO25/22) for Socket1, (GPIO24/27) for Socket2.
- AN pins go to **ADS1015** CH0/CH1 at I2C addr 0x48.

## Jumpers / Options (Board B)
- **CS select**: SJ-CS1 routes GPIO8(CE0) to Socket1; SJ-CS2 routes GPIO7(CE1) to Socket2.
- **UART sharing**: SJ-UART2 can tie Socket2 to the same TX/RX as Socket1 or isolate for a second UART from Board A.
- **PWM swap**: SJ-PWM can swap PWM0/PWM1 between sockets if needed.
- **INT/RST remap**: pads for alternate GPIOs; default as above.
- Label defaults on silk; orient mikroBUS sockets with pin-1 marks.

## Layout Guidance
- Place SPI series resistors near the driver (Board A) and keep SPI bus short between headers/sockets.
- Star the 3V3 plane to each socket; add 0.1µF at every mikroBUS VCC pin plus local bulk (10–22µF).
- Separate buck current loops from signal, stitch ground vias liberally around connectors and ESD/TVS.
- Respect Pi-HAT keep-outs and 11 mm stacking height between boards.
- Test pads: 5V, 3V3, GND, SCK, MOSI, MISO, SDA, SCL, TX, RX, PWM, INT, RST, AN0/AN1.

## Bring-Up Checklist
1. Power only: verify 5V & 3V3 rails and polyfuse operation; check TVS orientation.
2. I2C scan: expect ADS1015 at **0x48** (and HAT EEPROM at **0x50** if fitted).
3. UART: loopback TX↔RX on header to verify serial.
4. SPI: loopback MOSI↔MISO with 0Ω to sanity-check clock/data.
5. Fit one I2C Click, then SPI Click (select CS), then a UART Click.
6. Validate INT and RST routing using a Click with an INT line (e.g., accelerometer).

## Notes
- Many mikroBUS Clicks are **3.3V only**; verify before use.
- If MOCHAbin native GPIO is **1.8V**, ensure the translator reference on the low side is 1.8V (PCA9306 for I2C and AXC8T245 for push-pull).
- USB bridge option is great for portability; disable when using native GPIO by depopulating jumpers to avoid bus contention.

---

*Starter authored automatically. If you need a KiCad project skeleton with placed connectors and jumpers, you can derive it directly from these CSVs, or ask for a generated template.*
